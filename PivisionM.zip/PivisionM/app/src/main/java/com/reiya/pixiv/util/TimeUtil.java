package com.reiya.pixiv.util;

/**
 * Created by zhengyirui on 2017/8/29.
 */

public class TimeUtil {
    public static final long SECOND = 1000;
    public static final long MINUTE = SECOND * 60;
    public static final long HOUR = MINUTE * 60;
    public static final long DAY = HOUR * 24;
}
