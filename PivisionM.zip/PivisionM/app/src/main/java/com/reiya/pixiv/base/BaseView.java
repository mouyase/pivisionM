package com.reiya.pixiv.base;

/**
 * Created by lenovo on 2016/5/31.
 */

public interface BaseView<T extends BasePresenter> {
}
