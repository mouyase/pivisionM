package com.reiya.pixiv.main;


import android.support.v4.app.Fragment;

/**
 * Created by lenovo on 2016/10/6.
 */

abstract class MainFragment extends Fragment {

    abstract void changeLayoutManager();

    abstract void changeListStyle();
}
